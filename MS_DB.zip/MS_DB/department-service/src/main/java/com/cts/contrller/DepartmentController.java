package com.cts.contrller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Department;
import com.cts.service.DepartmentService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class DepartmentController {

	@Autowired
	DepartmentService service;

	@GetMapping("/departments")
	public List<Department> getDepartments(){
		log.info("started");
		log.debug("Departments are :{}",service.getDepartments());
		return service.getDepartments();
	}
	
	@GetMapping("/departments/{id}")
	public Department getDepartmentById(@PathVariable("id") int id){
		log.info("started");
		log.debug("Department is :{}",service.getDepartmentById(id));
		return service.getDepartmentById(id);
	}
	
}
