package com.cts.exception;



public class DepartmentException extends RuntimeException  {

	public DepartmentException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DepartmentException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
