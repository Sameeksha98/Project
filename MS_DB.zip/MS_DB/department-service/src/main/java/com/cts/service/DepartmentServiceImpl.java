package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.DepartmentException;
import com.cts.model.Department;
import com.cts.repository.DepartmentRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository repository;
	@Override
	public List<Department> getDepartments() {
		log.info("startted");
		List<Department> Departments=repository.findAll();
		log.debug("Departments are:{}"+Departments);
		return Departments;
	}

	@Override
	public Department getDepartmentById(int id) {
		log.info("started");
		Department loc=repository.findById(id).orElseThrow(()->
				new DepartmentException("Department with the id "+id+" doesn't exists"));
		return loc;
	}

}
