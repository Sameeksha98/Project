package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.LocationException;
import com.cts.model.Location;
import com.cts.repository.LocationRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class LocationServiceImpl implements LocationService {

	@Autowired
	LocationRepository repository;
	@Override
	public List<Location> getLocations() {
		log.info("startted");
		List<Location> locations=repository.findAll();
		log.debug("Locations are:{}"+locations);
		return locations;
	}

	@Override
	public Location getLocationById(int id) {
		log.info("started");
		Location loc=repository.findById(id).orElseThrow(()->
				new LocationException("Location with the id "+id+" doesn't exists"));
		return loc;
	}

}
