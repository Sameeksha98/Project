package com.cts.service;

import java.util.List;

import com.cts.model.Location;

public interface LocationService {

	List<Location> getLocations();
	Location getLocationById(int id);
}
