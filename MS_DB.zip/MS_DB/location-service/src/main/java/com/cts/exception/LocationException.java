package com.cts.exception;



public class LocationException extends RuntimeException  {

	public LocationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocationException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
