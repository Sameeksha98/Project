package com.cts.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cts.model.Department;
import com.cts.model.Employee;
import com.cts.model.EmployeeInfo;
import com.cts.model.Location;

@RestController
public class HRController {

	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/employeesinfo/{id}")
	public EmployeeInfo getEmployee(@PathVariable("id") int id) {
		EmployeeInfo einfo=null;
		Employee e=restTemplate.getForObject(
			"http://localhost:9092/employees/"+id, Employee.class);
		Department d=restTemplate.getForObject(
		"http://localhost:9091/departments/"+e.getDepartmentId(), Department.class);
		Location loc=restTemplate.getForObject(
		"http://localhost:9090/locations/"+d.getLocationId(), Location.class);
		einfo=new EmployeeInfo(e.getEid(), e.getName(), e.getGender(), e.getAge(), e.getSalary(), d.getDepartmentName(),loc.getLocationName());
		return einfo;
	}
	
	@GetMapping("/employeesinfo/dept/{id}")
	public List<EmployeeInfo> getEmployeeFromDepartment(@PathVariable("id") int id) {
		List<EmployeeInfo> elist=null;
		EmployeeInfo einfo=null;
		
		Department d=restTemplate.getForObject(
		"http://localhost:9091/departments/"+id, Department.class);
		Location loc=restTemplate.getForObject(
		"http://localhost:9090/locations/"+d.getLocationId(), Location.class);
		
		Employee[] emps=restTemplate.getForObject(
				"http://localhost:9092/employees/", Employee[].class);
	elist=Arrays.stream(emps)
			.filter(emp->emp.getDepartmentId()==id)
			.map(e->{ return new EmployeeInfo(
			e.getEid(), e.getName(), e.getGender(), e.getAge(), e.getSalary(), d.getDepartmentName(),loc.getLocationName());
			}).collect(Collectors.toList());
		return elist;
	}
}
