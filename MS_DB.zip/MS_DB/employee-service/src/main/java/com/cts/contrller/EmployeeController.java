package com.cts.contrller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.Employee;
import com.cts.service.EmployeeService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class EmployeeController {

	@Autowired
	EmployeeService service;

	@GetMapping("/employees")
	public List<Employee> getEmployees(){
		log.info("started");
		log.debug("Employees are :{}",service.getEmployees());
		return service.getEmployees();
	}
	
	@GetMapping("/employees/{id}")
	public Employee getEmployeeById(@PathVariable("id") int id){
		log.info("started");
		log.debug("Employee is :{}",service.getEmployeeById(id));
		return service.getEmployeeById(id);
	}
	
}
