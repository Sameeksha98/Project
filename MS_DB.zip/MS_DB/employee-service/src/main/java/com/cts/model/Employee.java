package com.cts.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Employee {

	@Id
	private int eid;
	private String name;
	private String gender;
	private int age;
	private double salary;
	private int departmentId;
}
