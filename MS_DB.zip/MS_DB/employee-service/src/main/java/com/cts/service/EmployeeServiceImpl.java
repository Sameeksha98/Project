package com.cts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.EmployeeException;
import com.cts.model.Employee;
import com.cts.repository.EmployeeRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepository repository;
	@Override
	public List<Employee> getEmployees() {
		log.info("startted");
		List<Employee> Employees=repository.findAll();
		log.debug("Employees are:{}"+Employees);
		return Employees;
	}

	@Override
	public Employee getEmployeeById(int id) {
		log.info("started");
		Employee loc=repository.findById(id).orElseThrow(()->
				new EmployeeException("Employee with the id "+id+" doesn't exists"));
		return loc;
	}

}
